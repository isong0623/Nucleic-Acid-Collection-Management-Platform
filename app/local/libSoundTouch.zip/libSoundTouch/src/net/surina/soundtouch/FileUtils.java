package net.surina.soundtouch;

import java.io.File;
import java.io.InputStream;
import java.io.OutputStream;

public class FileUtils {
    public static void delete(File f){
        if(!f.exists()) return;
        if(f.isDirectory()){
            File fs[] = f.listFiles();
            if(fs!=null){
                for(File f0:fs){
                    delete(f0);
                }
            }
        }
        f.delete();
    }

    public static void autoMkdirs(File f){
        if(f.getAbsolutePath().endsWith("\\")||f.getAbsolutePath().endsWith("/")){
            if(!f.exists()) f.mkdirs();
            return;
        }
        if(!f.getParentFile().exists())f.getParentFile().mkdirs();
    }

    public static void createFile(File f){
        delete(f);
        createFile(f);
    }

    public static void recreateFile(File f){
        autoMkdirs(f);
        if(!f.exists()) {
            try { f.createNewFile(); } catch (Exception e) { }
        }
    }

    public static void copy(InputStream is, OutputStream os) {
        try {
            byte[] buffer = new byte[4096];
            int readCount;
            while((readCount = is.read(buffer))>0){
                os.write(buffer,0,readCount);
                os.flush();
            }
        } catch (Exception e) { }
        finally {
            try { is.close(); } catch (Exception e) { e.printStackTrace(); }
            try { os.close(); } catch (Exception e) { e.printStackTrace(); }
        }
    }

}

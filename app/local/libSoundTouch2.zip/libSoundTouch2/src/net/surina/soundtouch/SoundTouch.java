////////////////////////////////////////////////////////////////////////////////
///
/// Example class that invokes native SoundTouch routines through the JNI
/// interface.
///
/// Author        : Copyright (c) Olli Parviainen
/// Author e-mail : oparviai 'at' iki.fi
/// WWW           : http://www.surina.net
///
////////////////////////////////////////////////////////////////////////////////

package net.surina.soundtouch;

import android.util.Log;

public final class SoundTouch {
    // Native interface function that returns SoundTouch version string.
    // This invokes the native c++ routine defined in "soundtouch-jni.cpp".
    public native final static String getVersionString();

    private native final void setTempo(long handle, float tempo);

    private native final void setPitchSemiTones(long handle, float pitch);

    private native final void setSpeed(long handle, float speed);

    private native final int processFile(long handle, String inputFile, String outputFile);

    public native final static String getErrorString();

    private native final static long newInstance();

    private native final void deleteInstance(long handle);

    long handle = 0;


    public SoundTouch() {
        handle = newInstance();
    }


    public void close() {
        deleteInstance(handle);
        handle = 0;
    }


    public SoundTouch setTempo(float tempo) {
        setTempo(handle, tempo);
        return this;
    }


    public SoundTouch setPitchSemiTones(float pitch) {
        setPitchSemiTones(handle, pitch);
        return this;
    }


    public SoundTouch setSpeed(float speed) {
        setSpeed(handle, speed);
        return this;
    }


    public int processFile(String inputFile, String outputFile) {
        return processFile(handle, inputFile, outputFile);
    }

    private static final String TAG = SoundTouch.class.getSimpleName();
    public static synchronized boolean process(float tempo, String inputPath, String outputPath){
        return process(tempo,-0.318f,inputPath,outputPath);
    }
    public static synchronized boolean process(float tempo, float pitch, String inputPath, String outputPath){
        SoundTouch st = new SoundTouch()
                            .setTempo(tempo)
                            .setPitchSemiTones(pitch);

        long startTime = System.currentTimeMillis();
        Log.i(TAG, "process file " + inputPath);
        int result = st.processFile(inputPath,outputPath);
        long endTime = System.currentTimeMillis();
        float duration = (endTime - startTime) * 0.001f;
        Log.i(TAG, "process file done, duration = " + duration);

        if (result != 0) {
            String err = SoundTouch.getErrorString();
            Log.i(TAG,"process failure, "+err);
        }
        else{
            Log.i(TAG,"process success!");
        }

        return result == 0;
    }

    // Load the native library upon startup
    static {
        System.loadLibrary("soundtouch");
        Log.i(TAG,"loading library success:"+getVersionString());
    }
}

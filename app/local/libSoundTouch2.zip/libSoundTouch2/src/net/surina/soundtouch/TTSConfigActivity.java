package com.dreaming.hscj.activity.system;

import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.SeekBar;
import android.widget.TextView;

import androidx.constraintlayout.widget.ConstraintLayout;

import com.dreaming.hscj.R;
import com.dreaming.hscj.base.BaseActivity;
import com.dreaming.hscj.core.TTSEngine;

import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

public class TTSConfigActivity extends BaseActivity {
    @Override
    public int getContentViewResId() {
        return R.layout.activity_tts_config;
    }

    @BindView(R.id.part_initials_speed)
    ConstraintLayout clInitialsSpeed;
    @BindView(R.id.part_initials_tones)
    ConstraintLayout clInitialsTones;
    @BindView(R.id.part_vowels_head_speed)
    ConstraintLayout clVowelsHeadSpeed;
    @BindView(R.id.part_vowels_head_tones)
    ConstraintLayout clVowelsHeadTones;
    @BindView(R.id.part_vowels_center_speed)
    ConstraintLayout clVowelsCenterSpeed;
    @BindView(R.id.part_vowels_center_tones)
    ConstraintLayout clVowelsCenterTones;
    @BindView(R.id.part_vowels_tail_speed)
    ConstraintLayout clVowelsTailSpeed;
    @BindView(R.id.part_vowels_tail_tones)
    ConstraintLayout clVowelsTailTones;
    @BindView(R.id.part_pause_1)
    ConstraintLayout clPause1;
    @BindView(R.id.part_pause_2)
    ConstraintLayout clPause2;
    @BindView(R.id.part_pause_3)
    ConstraintLayout clPause3;
    @BindView(R.id.part_pause_4)
    ConstraintLayout clPause4;
    @BindView(R.id.part_pause_5)
    ConstraintLayout clPause5;
    @BindView(R.id.part_pause_6)
    ConstraintLayout clPause6;
    @BindView(R.id.part_alphabet_speed)
    ConstraintLayout clAlphabetSpeed;
    @BindView(R.id.part_alphabet_tones)
    ConstraintLayout clAlphabetTones;

    @Override
    protected void onBindView(View vContent) {
        ButterKnife.bind(this,vContent);
    }
    private List<String[]> lstTTSConfig = TTSEngine.getTTSConfig();
    String getValueText(int progress, int type){
        switch (type){
            case 0:
            case 2:
            case 4:
            case 6:
            case 14:{
                int iMin = Integer.parseInt(lstTTSConfig.get(type)[2]);
                int iMax = Integer.parseInt(lstTTSConfig.get(type)[3]);
                int result = (int)((iMax - iMin)*progress/100d )+iMin;
                return String.format("%.1f倍",result/100d);
            }
            case 1:
            case 3:
            case 5:
            case 7:
            case 15:{
                double dMin = Double.parseDouble(lstTTSConfig.get(type)[2]);
                double dMax = Double.parseDouble(lstTTSConfig.get(type)[3]);
                return String.format("%.2f", (dMax-dMin)*progress/100d+dMin);
            }
            case 8 :
            case 9 :
            case 10:
            case 11:
            case 12:
            case 13:{
                int iMin = Integer.parseInt(lstTTSConfig.get(type)[2]);
                int iMax = Integer.parseInt(lstTTSConfig.get(type)[3]);
                int result = (int)((iMax - iMin)/100d * progress);
                return result+"ms";
            }
        }
        return "";
    }

    void initViewItem(final ConstraintLayout cl, int type){
        TextView tv = (TextView) cl.getChildAt(0);
        tv.setText(lstTTSConfig.get(type)[0]);

        int progress = Integer.valueOf(lstTTSConfig.get(type)[1]);
        SeekBar sb = (SeekBar) cl.getChildAt(1);
        sb.setProgress(progress);
        sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                TextView tvShow = (TextView) cl.getChildAt(2);
                tvShow.setText(getValueText(progress,type));
                TTSEngine.setProgress(type,progress);
            }
            @Override
            public void onStartTrackingTouch(SeekBar seekBar) { }
            @Override
            public void onStopTrackingTouch(SeekBar seekBar) { }
        });

        TextView tvShow = (TextView) cl.getChildAt(2);
        tvShow.setText(getValueText(progress,type));
    }

    void reset(){
        for(int i=0;i<16;++i){
            TTSEngine.setProgress(i,-1);
        }
        lstTTSConfig = TTSEngine.getTTSConfig();
        initView();
    }

    @Override
    public void initView() {
        setCenterText("TTS文字转语音引擎");
        setRightText("重置");
        for(int i=0;i<16;++i){
            Log.e("TTS",lstTTSConfig.get(i)[1]);
        }
        tvTitleRight.setOnClickListener(v -> reset());
        initViewItem(clInitialsSpeed    ,0 );
        initViewItem(clInitialsTones    ,1 );
        initViewItem(clVowelsHeadSpeed  ,2 );
        initViewItem(clVowelsHeadTones  ,3 );
        initViewItem(clVowelsCenterSpeed,4 );
        initViewItem(clVowelsCenterTones,5 );
        initViewItem(clVowelsTailSpeed  ,6 );
        initViewItem(clVowelsTailTones  ,7 );
        initViewItem(clPause1           ,8 );
        initViewItem(clPause2           ,9 );
        initViewItem(clPause3           ,10);
        initViewItem(clPause4           ,11);
        initViewItem(clPause5           ,12);
        initViewItem(clPause6           ,13);
        initViewItem(clAlphabetSpeed    ,14);
        initViewItem(clAlphabetTones    ,15);
    }

    @BindView(R.id.et_read)
    EditText etReadText;
    @OnClick(R.id.tv_read)
    void readText(){
        String text = etReadText.getText().toString();
        TTSEngine.speakChinese(text);
    }
}

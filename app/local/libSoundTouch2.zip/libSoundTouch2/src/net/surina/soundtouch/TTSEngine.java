package net.surina.soundtouch;

import android.content.Context;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.SoundPool;
import android.net.Uri;
import android.util.Log;
import android.util.Pair;

import com.air4.chinesetts.tts.TtsManager;
import com.dreaming.hscj.App;
import com.dreaming.hscj.utils.FileUtils;
import com.dreaming.hscj.utils.PinyinUtil;
import com.dreaming.hscj.utils.SPUtils;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import priv.songxusheng.easyjson.ESONObject;

public class TTSEngine {

    private static final String TAG = TTSEngine.class.getSimpleName();

    private static String key = "TTSEngine_Config_";
    private static int getProgress(int type){
        return getProgress(type,-1);
    }
    private static int getProgress(int type,int defaultValue){
        int value = SPUtils.Sys.getInt(key+type,defaultValue);
        return value <0||value>100 ? defaultValue : value;
    }
    public static Boolean setProgress(int type, int progress){
        return SPUtils.Sys.commitInt(key+type,progress);
    }

    public static List<String[]> getTTSConfig(){
        return new ArrayList(){{
            //名称 默认进度 最小值 最大值
            add(new String[]{"声母语速：",String.valueOf(getProgress(0 ,66)),"0"   ,"1500"});
            add(new String[]{"声母音高：",String.valueOf(getProgress(1 ,61)),"-5.0","5.0" });
            add(new String[]{"韵头语速：",String.valueOf(getProgress(2 ,14)),"0"   ,"1500"});
            add(new String[]{"韵头音高：",String.valueOf(getProgress(3 ,75)),"-5.0","5.0" });
            add(new String[]{"韵腹语速：",String.valueOf(getProgress(4 ,14)),"0"   ,"1500"});
            add(new String[]{"韵腹音高：",String.valueOf(getProgress(5 ,59)),"-5.0","5.0" });// 5
            add(new String[]{"韵尾语速：",String.valueOf(getProgress(6 ,14)),"0"   ,"1500"});
            add(new String[]{"韵尾音高：",String.valueOf(getProgress(7 ,74)),"-5.0","5.0" });
            add(new String[]{"音节停顿：",String.valueOf(getProgress(8 ,0 )),"0"   ,"1000"});
            add(new String[]{"头腹停顿：",String.valueOf(getProgress(9 ,0 )),"0"   ,"1000"});
            add(new String[]{"腹尾停顿：",String.valueOf(getProgress(10,31)),"0"   ,"1000"});//10
            add(new String[]{"逗号停顿：",String.valueOf(getProgress(11,65)),"0"   ,"1500"});
            add(new String[]{"句号停顿：",String.valueOf(getProgress(12,10)),"0"   ,"2000"});
            add(new String[]{"字间停顿：",String.valueOf(getProgress(13,26)),"0"   ,"2000"});
            add(new String[]{"字母语速：",String.valueOf(getProgress(14,60)),"0"   ,"1500"});
            add(new String[]{"字母音高：",String.valueOf(getProgress(15,45)),"-5.0","5.0" });//15
        }};
    }
    private static ESONObject readConfig(){
        StringBuilder sb = new StringBuilder();
        try {
            String outDir = App.sInstance.getCacheDir().getAbsolutePath()+"/tts/TTSConfig.json";
            FileUtils.copy(App.sInstance.getResources().getAssets().open("tts/TTSConfig.json"),new FileOutputStream(outDir));

            FileReader fr = new FileReader(outDir);
            BufferedReader bf = new BufferedReader(fr);
            String str;
            // 按行读取字符串
            while ((str = bf.readLine()) != null) {
                sb.append(str);
            }
            bf.close();
            fr.close();
        } catch (Exception e) {
        }

        return new ESONObject(sb.toString());
    }
    private static ESONObject TTSTimeConfig = readConfig();

    private static float readTempo(String config[], String name){
        int progressOfTempo = Integer.parseInt   (config[1]);
        int minOfTempo      = Integer.parseInt   (config[2]);
        int maxOfTempo      = Integer.parseInt   (config[3]);
        return (maxOfTempo - minOfTempo)*progressOfTempo/100f/100f*TTSTimeConfig.getJSONValue(name,500)/500f ;
    }

    private static float readPitch(String config[]){
        int progressOfPitch = Integer.parseInt   (config[1]);
        double minOfPitch   = Double .parseDouble(config[2]);
        double maxOfPitch   = Double .parseDouble(config[3]);
        return (float) ((maxOfPitch - minOfPitch)*progressOfPitch/100f + minOfPitch);
    }

    private static Set<String> sInitials   = new HashSet<String>(){{
        add("b");
        add("c");
        add("ch");
        add("d");
        add("f");
        add("g");
        add("h");
        add("j");
        add("k");
        add("l");
        add("m");
        add("n");
        add("p");
        add("q");
        add("r");
        add("s");
        add("sh");
        add("t");
        add("w");
        add("x");
        add("y");
        add("z");
        add("zh");
    }};
    private static Set<String> sVowels     = new HashSet<String>(){{
        add("a");
        add("ai");
        add("an");
        add("ang");
        add("ao");
        add("bo");
        add("chi");
        add("ci");
        add("de");
        add("e");
        add("ei");
        add("en");
        add("eng");
        add("er");
        add("fo");
        add("ge");
        add("he");
        add("i");
        add("ie");
        add("in");
        add("ing");
        add("iu");
        add("ji");
        add("ke");
        add("le");
        add("mo");
        add("ne");
        add("o");
        add("ong");
        add("ou");
        add("po");
        add("qi");
        add("ri");
        add("shi");
        add("si");
        add("te");
        add("u");
        add("ui");
        add("un");
        add("v");
        add("ve");
        add("vn");
        add("wu");
        add("xi");
        add("ye");
        add("yi");
        add("yin");
        add("ying");
        add("yu");
        add("yuan");
        add("yue");
        add("yun");
        add("zhi");
        add("zi");
    }};
    private static Set<String> sFullVowels = new HashSet<String>(){{
        add("zhi");
        add("chi");
        add("shi");
        add("ri");
        add("zi");
        add("ci");
        add("si");
        add("yi");
        add("wu");
        add("yu");
        add("ye");
        add("yue");
        add("yuan");
        add("yin");
        add("yun");
        add("ying");
    }};

    private static synchronized void speakPinyin(String pinyin, List<String> lstSounds){
        if(pinyin==null || pinyin.isEmpty()) return;
        pinyin = pinyin.trim().toLowerCase();

        if(sFullVowels.contains(pinyin.replaceAll("[1-4]",""))){
            lstSounds.add("韵腹"+pinyin);
            return;
        }

        String initials = pinyin.substring(0,pinyin.length()>1?2:1);
        if(!sInitials.contains(initials)){
            initials = pinyin.substring(0,1);
        }
        if(sInitials.contains(initials)){
            lstSounds.add(initials);
            lstSounds.add("-8");
        }
        else{
            initials = "";
        }

        String vowels = pinyin.substring(initials.length()).trim();
        if(vowels.isEmpty()){
            vowels = "a1";
        }

        String tones  = vowels.substring(vowels.length()-1);
        if(!PinyinUtil.isDigit(tones.charAt(0))) tones = "1";
        vowels = vowels
                .replaceAll("[1-4]*","")
                .replaceAll("u:e","ve")
                .replaceAll("u:n","vn")
                .replaceAll("u:","v");

        if(sVowels.contains(vowels)){
            lstSounds.add("韵腹"+vowels+tones);
            return;
        }
        for(int i=1,ni=vowels.length()-1;i<ni;++i){
            String head = vowels.substring(0,i);
            if(!sVowels.contains(head)) continue;

            String maybeTail = vowels.substring(i);
            if(sVowels.contains(maybeTail)){
                lstSounds.add("韵头"+head+tones);
                lstSounds.add("-9");
                lstSounds.add("韵腹"+maybeTail+tones);
                return;
            }

            for(int j = i+1;j<ni;++j){
                String center = vowels.substring(i,j);
                if(!sVowels.contains(center)) continue;
                String tail = vowels.substring(j);
                if(!sVowels.contains(tail)) continue;
                lstSounds.add("韵头"+head+tones);
                lstSounds.add("-9");
                lstSounds.add("韵腹"+center+tones);
                lstSounds.add("-10");
                lstSounds.add("韵尾"+tail+tones);
                return;
            }
        }

        //匹配失败
        lstSounds.add("韵腹a"+tones);
    }

    /**
     * 获取音频播放时长
     * @param fAudio
     * @return
     */
    private static int getAudioDuration(File fAudio) {
        try {
            MediaPlayer mediaPlayer = new MediaPlayer();
            mediaPlayer.setDataSource(App.sInstance, Uri.fromFile(fAudio));
            mediaPlayer.setAudioStreamType(AudioManager.STREAM_MUSIC);
            mediaPlayer.prepare();
            return mediaPlayer.getDuration();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return 0;
    }

    private static final String CHINESE_NUMBER = "零一二三四五六七八九十";
    private static final String CHINESE_DOT    = "点";

    /**
     * 文字转语音并播报
     * @param strChinese
     */
    public static synchronized void speakChinese(final String strChinese){
        TtsManager.getInstance().speak(strChinese, 1, true);
        if(true) return;
        ThreadPoolProvider.getFixedThreadPool().execute(()->{
            //"-X":表示对应的X类型停顿 'A'~'Z':字母 '0'~'9':数字 其他：声韵母
            List<String> lstSounds = new ArrayList<>();

            //region 分类
            String chinese = strChinese;
            if(chinese==null) chinese = "";
            chinese = chinese.trim();
            for(int i=0,soundIndex=-10,ni=chinese.length();i<ni;++i){
                char ch = chinese.charAt(i);
                char p  = i>0?chinese.charAt(i-1):'a';
                char n  = i+1<ni?chinese.charAt(i+1):'a';

                if(PinyinUtil.isLittlePause(ch)){//逗号
                    lstSounds.add("-11");
                    continue;
                }

                if(PinyinUtil.isLargerPause(ch,p,n)){//句号
                    lstSounds.add("-12");
                    continue;
                }

                if(PinyinUtil.isDot(ch,p,n)){//点
                    if(soundIndex == i-1) lstSounds.add("-13");
                    speakPinyin(PinyinUtil.hanziToPinyin(CHINESE_DOT),lstSounds);
                    soundIndex = i;
                    continue;
                }

                if(PinyinUtil.isChineseSymbol(ch)) continue;
                if(PinyinUtil.isChinese(ch)){
                    if(soundIndex == i-1) lstSounds.add("-13");
                    speakPinyin(PinyinUtil.hanziToPinyin(ch+""),lstSounds);
                    soundIndex = i;
                    continue;
                }

                if(PinyinUtil.isAlphabet(ch)){
                    if(soundIndex == i-1) lstSounds.add("-13");
                    lstSounds.add((ch+"").toUpperCase());
                    soundIndex = i;
                    continue;
                }

                if(PinyinUtil.isDigit(ch)){
                    if(soundIndex == i-1) lstSounds.add("-13");
                    speakPinyin(PinyinUtil.hanziToPinyin(CHINESE_NUMBER.substring(ch-'0',ch-'0'+1)),lstSounds);
                    soundIndex = i;
                }
            }
            //endregion

            //region 文字转换音频
            File fSoundCacheDir = new File(App.sInstance.getCacheDir().getAbsolutePath(),"/tts/cache/");
            if(fSoundCacheDir.exists()) FileUtils.delete(fSoundCacheDir);
            FileUtils.autoMkdirs(fSoundCacheDir);
            List<String[]> lstTTSConfig = getTTSConfig();
            SoundPool soundPool = new SoundPool(1, AudioManager.STREAM_MUSIC, 100);
            List<Pair<Integer,Integer>> lstSoundPool = new ArrayList<>();

            for(int i=0,ni=lstSounds.size();i<ni;++i){
                String sound = lstSounds.get(i);
                char ch = sound.charAt(0);

                try {
                    if(ch=='-'){
                        int type     = Integer.parseInt(sound.substring(1));
                        int interval = Integer.parseInt(lstTTSConfig.get(type)[1]);
                        lstSoundPool.add(new Pair(-1,interval));
                        continue;
                    }
                    long timestamp = System.currentTimeMillis();
                    File fCache = new File(fSoundCacheDir,timestamp+".wav");
                    FileUtils.recreateFile(fCache);
                    FileOutputStream fos = new FileOutputStream(fCache);
                    float fTempo = 0f;
                    float fPitch = 0f;
                    if(ch>='A'&&ch<='Z'){
                        InputStream is = App.sInstance.getResources().getAssets().open(String.format("tts/alphabet/%s.wav",sound));
                        FileUtils.copy(is,fos);
                        fTempo = readTempo(lstTTSConfig.get(14),sound);
                        fPitch = readPitch(lstTTSConfig.get(15));
                    }
                    else{

                        if(sInitials.contains(sound)){
                            fTempo = readTempo(lstTTSConfig.get(0),sound);
                            fPitch = readPitch(lstTTSConfig.get(1));
                            InputStream is = App.sInstance.getResources().getAssets().open(String.format("tts/chinese/%s/%s.wav","initials",sound));
                            FileUtils.copy(is,fos);
                        }
                        else{
                            String type = sound.substring(0,2);
                            InputStream is = App.sInstance.getResources().getAssets().open(String.format("tts/chinese/%s/%s.wav","vowels",sound.substring(2)));
                            FileUtils.copy(is,fos);
                            if("韵头".equals(type)){
                                fTempo = readTempo(lstTTSConfig.get(2),sound);
                                fPitch = readPitch(lstTTSConfig.get(3));
                            }
                            if("韵腹".equals(type)){
                                fTempo = readTempo(lstTTSConfig.get(4),sound);
                                fPitch = readPitch(lstTTSConfig.get(5));
                            }
                            if("韵尾".equals(type)){
                                fTempo = readTempo(lstTTSConfig.get(6),sound);
                                fPitch = readPitch(lstTTSConfig.get(7));
                            }
                        }
                    }

                    Log.e(TAG,String.format("tempo:%.1f pitch:%.2f",fTempo,fPitch));
                    File fOut = new File(fSoundCacheDir,timestamp+"_out.wav");

                    if(SoundTouch.process(fTempo,fPitch,fCache.getAbsolutePath(),fOut.getAbsolutePath())){
                        lstSoundPool.add(new Pair(getAudioDuration(fOut),soundPool.load(fOut.getAbsolutePath(),lstSoundPool.size())));
                    }

                } catch (Exception e) {}
            }
            //endregion

            //region 播报音频
            AudioManager mgr = (AudioManager) App.sInstance.getSystemService(Context.AUDIO_SERVICE);
            float streamVolumeCurrent = mgr.getStreamVolume(AudioManager.STREAM_MUSIC);
            float streamVolumeMax = mgr.getStreamMaxVolume(AudioManager.STREAM_MUSIC);
            float volume = streamVolumeCurrent/streamVolumeMax;
            for(int i=0,ni=lstSoundPool.size();i<ni;++i){
                Pair<Integer,Integer> p = lstSoundPool.get(i);
                long now = System.currentTimeMillis();
                long end;
                if(p.first==-1){
                    end = p.second + now;
                }
                else{
                    end = p.first + now;
                    //参数：1、pool_id   2、当前音量     3、最大音量  4、优先级   5、重播次数   6、播放速度
                    soundPool.play(lstSoundPool.get(i).second, volume, volume, 1, 0, 1f);
                    Log.e(TAG,"playing "+lstSoundPool.get(i).second);
                }
                while(System.currentTimeMillis()<end){
                    try { Thread.sleep(1); } catch (Exception e) { e.printStackTrace(); }
                }
            }
            //endregion
        });
    }

}
